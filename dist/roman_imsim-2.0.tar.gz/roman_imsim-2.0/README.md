# wfirst_imsim

Nonstandard dependencies are represented in setup.py.

See wiki for information on how to run and documentation.

